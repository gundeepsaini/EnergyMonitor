


Additional Libraries
----------------------


Steps:

1. Move the folders from here to the Arduino lib folder (in the sketchbook folder). No change of names / structure required.


Why do this?
- Maintaining a copy of libraries that works with the hardware so that in case of future changes to these libraries or deletions, my copy is able to compile successfully.


Why not merge with the src folder?
- Src folder contents gets compiled. These lib files and structure needs to be changed before that is possible and since I do have time right now, I have just copied the files here directly.

